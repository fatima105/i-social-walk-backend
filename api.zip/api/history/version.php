<?php
echo phpinfo();
