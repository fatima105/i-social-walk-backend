
<?php

$data = json_decode(file_get_contents("php://input"), true);
$name = $data['name'];
$this_user_id = $data['this_user_id'];
include('../include/connection.php');
$sql = "Select * from friend_list WHERE  this_user_id='$this_user_id' AND status='approved'";

$result = mysqli_query($conn, $sql);

$rowcount = mysqli_num_rows($result);
if ($rowcount > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $user_id = $row['friend_user_id'];
    }

    

    $response[] = array('error' => 'false', 'Message' => 'Succesfully fetched friends', 'friends ' => $first_name);
} else {

    $response[] = array(
        "message" => 'Empty friendlist',

        "error" => false

    );
}
echo json_encode($response);
?>
