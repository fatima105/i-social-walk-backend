<?php
include('../include/connection.php');
$EncodeData = file_get_contents('php://input');
$data = json_decode($EncodeData, true);

$id = $data['id'];
$sql = "UPDATE notification SET status='read' where  AND id='$id'";
$queryrun = mysqli_query($conn, $sql);

$sql1 = "SELECT * from notification where id='$id'";
$queryrun1 = mysqli_query($conn, $sql1);
if ($queryrun1) {
    while ($row = mysqli_fetch_assoc($queryrun1)) {
    }

    $sqlquery = "UPDATE challenges_groups SET status='membered' where noti_type_id='$id'";
    $queryrunupdate = mysqli_query($conn, $sqlquery);
    if ($queryrunupdate) {
        $response = array(
            "message" => 'updated',
            "error" => true
        );
    }
}
echo json_encode($response);
